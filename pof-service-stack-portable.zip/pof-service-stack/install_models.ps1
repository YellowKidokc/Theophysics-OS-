param(
    [string]$ModelId = "",
    [string]$Destination = "",
    [string]$Downloader = "",
    [Parameter(ValueFromRemainingArguments = $true)]
    [string[]]$ExtraArgs
)

function Resolve-Downloader {
    param([string]$ExplicitPath)

    $cands = @()
    if ($ExplicitPath) { $cands += $ExplicitPath }
    $cands += @(
        (Join-Path $PSScriptRoot 'download_nlp_models.py'),
        (Join-Path $PSScriptRoot '..\..\download_nlp_models.py'),
        (Join-Path $PSScriptRoot '..\..\nlp_api\download_nlp_models.py'),
        (Join-Path $PSScriptRoot '..\..\..\download_nlp_models.py')
    )
    if ($env:POF_MODEL_DOWNLOAD_SCRIPT) { $cands = @($env:POF_MODEL_DOWNLOAD_SCRIPT) + $cands }

    foreach ($p in $cands) {
        try {
            $t = [IO.Path]::GetFullPath($p)
            if (Test-Path $t) { return $t }
        } catch {}
    }
    return ""
}

function Usage {
    Write-Output "Usage:"
    Write-Output "  install_models.bat <model-id|folder> [--args ...]"
    Write-Output "  install_models.bat --help"
    Write-Output ""
    Write-Output "Examples:"
    Write-Output "  install_models.bat 01_CONTRADICTION_PRIMARY"
    Write-Output "  install_models.bat 13_IMAGE_CAPTION -- --force"
    Write-Output ""
    Write-Output "Env:"
    Write-Output "  POF_MODEL_DOWNLOAD_SCRIPT  explicit path to download_nlp_models.py"
    Write-Output "  POF_MODEL_ROOT            override destination root for downloads"
}

$downloader = Resolve-Downloader $Downloader
if (-not $downloader) {
    Write-Error "Could not locate download_nlp_models.py"
    Usage
    exit 2
}

$python = Get-Command python -ErrorAction SilentlyContinue
if (-not $python) {
    Write-Error "Python not found in PATH"
    exit 3
}

if ($ModelId -eq '' -or $ModelId -eq '--help' -or $ModelId -eq '-h' -or $ModelId -eq '/?') {
    Usage
    exit 0
}

$argsList = New-Object System.Collections.Generic.List[string]
if ($Destination -or $env:POF_MODEL_ROOT) {
    $root = if ($Destination) { $Destination } else { $env:POF_MODEL_ROOT }
    $argsList.Add('--destination')
    $argsList.Add($root)
}

$argsList.Add($ModelId)
if ($ExtraArgs -and $ExtraArgs.Count -gt 0) {
    foreach ($a in $ExtraArgs) { $argsList.Add($a) }
}
if ($env:POF_DISABLE_BROWSER -eq '1') {
    $argsList.Add('--quiet')
}

Write-Output "[model-installer] python $downloader $($argsList -join ' ')"
$argList = @($downloader) + [string[]]$argsList
& $python.Source @argList
exit $LASTEXITCODE
