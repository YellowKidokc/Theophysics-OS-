@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0pof_service_bootstrap.ps1" %*
exit /b %ERRORLEVEL%
