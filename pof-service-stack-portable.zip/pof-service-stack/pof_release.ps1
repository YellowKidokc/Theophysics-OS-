param(
    [string]$DestinationDir = "D:\GitHub\Theophysics-OS-",
    [string]$DestZipName = "pof-service-stack-portable.zip"
)

function Get-Sha256Hex {
    param([Parameter(Mandatory = $true)][string]$FilePath)

    $sha256 = [System.Security.Cryptography.SHA256]::Create()
    try {
        $stream = [System.IO.File]::OpenRead($FilePath)
        try {
            $bytes = $sha256.ComputeHash($stream)
        } finally {
            $stream.Dispose()
        }
    } finally {
        $sha256.Dispose()
    }

    return ($bytes | ForEach-Object { $_.ToString("x2") }) -join ''
}

$scriptRoot = $PSScriptRoot
$startupRoot = Split-Path -Parent $scriptRoot
$sourceZip = Join-Path $startupRoot "pof-service-stack-portable.zip"
$versionFile = Join-Path $scriptRoot "VERSION"
$releaseManifest = Join-Path $startupRoot "pof-service-stack-release.json"
$releaseHash = Join-Path $startupRoot "pof-service-stack-portable.sha256"
$exportScript = Join-Path $startupRoot "pof_export_bundle.bat"
$destZip = Join-Path $DestinationDir $DestZipName
$destManifest = Join-Path $DestinationDir "pof-service-stack-release.json"
$destHash = Join-Path $DestinationDir "pof-service-stack-portable.sha256"

if (-not (Test-Path $exportScript)) {
    Write-Error "[pof_release] missing export script: $exportScript"
    exit 1
}

if (-not (Test-Path (Split-Path $versionFile))) {
    Write-Error "[pof_release] missing version directory: $scriptRoot"
    exit 1
}

$version = "0.0.0"
if (Test-Path $versionFile) {
    $rawVersion = Get-Content -Raw -Path $versionFile
    $trimmed = $rawVersion.Trim()
    if ($trimmed) { $version = $trimmed }
}

Push-Location $startupRoot
try {
    & "$exportScript"
    if ($LASTEXITCODE -ne 0 -or -not (Test-Path $sourceZip)) {
        Write-Error "[pof_release] bundle export failed"
        exit 1
    }
} finally {
    Pop-Location
}

$hash = Get-Sha256Hex -FilePath $sourceZip
$size = (Get-Item $sourceZip).Length
$utc = (Get-Date).ToUniversalTime().ToString("o")

$manifest = [ordered]@{
    name = "pof-service-stack"
    version = $version
    built_at_utc = $utc
    built_host = $env:COMPUTERNAME
    zip_file = [System.IO.Path]::GetFileName($sourceZip)
    zip_size_bytes = $size
    sha256 = $hash
}
$manifest | ConvertTo-Json -Depth 2 | Set-Content -Path $releaseManifest -Encoding utf8
"$hash  $([System.IO.Path]::GetFileName($sourceZip))" | Set-Content -Path $releaseHash -Encoding ascii

if (-not (Test-Path $DestinationDir)) {
    Write-Error "[pof_release] destination missing: $DestinationDir"
    exit 2
}

Copy-Item -Path $sourceZip -Destination $destZip -Force
Copy-Item -Path $releaseManifest -Destination $destManifest -Force
Copy-Item -Path $releaseHash -Destination $destHash -Force

Write-Host "[pof_release] version: $version"
Write-Host "[pof_release] bundle: $destZip"
Write-Host "[pof_release] manifest: $destManifest"
Write-Host "[pof_release] hash: $releaseHash"
