param(
    [Parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][string]$ServiceId,
    [ValidateSet('status','start','stop','selfcheck')][string]$Action = 'status',
    [string]$ConfigPath = (Join-Path $PSScriptRoot 'service_bundle.config.json')
)

$cfg = Get-Content -LiteralPath $ConfigPath -Raw | ConvertFrom-Json
$service = $cfg.services | Where-Object { $_.id -eq $ServiceId }
if (-not $service) {
    Write-Output ("{\"error\":\"Unknown service id '$ServiceId'\"}")
    exit 10
}
$python = Get-Command python -ErrorAction SilentlyContinue
$auditScript = Join-Path $PSScriptRoot 'pof_audit.py'
$auditEnabled = $false
if ($python -and (Test-Path $auditScript)) { $auditEnabled = $true }

$serviceCwd = [string]$service.cwd
if ($serviceCwd -eq '__SELF__') {
    $serviceCwd = $PSScriptRoot
} elseif ($serviceCwd -like '__SELF__\*' -or $serviceCwd -like '__SELF__/*') {
    $serviceCwd = Join-Path $PSScriptRoot ($serviceCwd -replace '^__SELF__[/\\]', '')
}

$remoteHost = [Environment]::GetEnvironmentVariable('POF_REMOTE_HOST')
if ([string]::IsNullOrWhiteSpace($remoteHost)) { $remoteHost = $cfg.bootstrap.remote_host }
$remotePort = [Environment]::GetEnvironmentVariable('POF_REMOTE_PORT')
if ([string]::IsNullOrWhiteSpace($remotePort)) { $remotePort = [string]$cfg.bootstrap.remote_port }

function Test-PortOpen {
    param([string]$Host, [int]$Port, [int]$TimeoutMs = 700)
    $client = New-Object System.Net.Sockets.TcpClient
    try {
        $iar = $client.BeginConnect($Host, $Port, $null, $null)
        if ($iar.AsyncWaitHandle.WaitOne($TimeoutMs, $true) -and $client.Connected) {
            $client.EndConnect($iar)
            $client.Close()
            return $true
        }
    } catch {}
    return $false
}

function Get-PortPids {
    param([int]$Port)
    $ids = @()
    if (Get-Command Get-NetTCPConnection -ErrorAction SilentlyContinue) {
        try {
            $ids = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue |
                Select-Object -ExpandProperty OwningProcess -Unique
        } catch {}
    }
    if (-not $ids -or $ids.Count -eq 0) {
        try {
            $lines = netstat -ano 2>$null | Select-String LISTENING
            foreach ($line in $lines) {
                $parts = ($line.ToString().Trim() -split '\s+')
                if ($parts.Count -lt 5) { continue }
                $local = $parts[1]
                if ($local -match ':(\d+)$') {
                    if ([int]$Matches[1] -eq $Port) {
                        $ids += [int]$parts[4]
                    }
                }
            }
        } catch {}
    }
    return $ids | Sort-Object -Unique
}

function Wait-ServiceUp {
    param([int]$Port, [int]$TimeoutSec = 8)
    $deadline = (Get-Date).AddSeconds($TimeoutSec)
    while ((Get-Date) -lt $deadline) {
        if (Test-PortOpen '127.0.0.1' $Port 300) { return $true }
        Start-Sleep -Milliseconds 500
    }
    return $false
}

$AuditAction = [ordered]@{
    action = $Action
    service = $service.id
    result = "ok"
    severity = "info"
    message = ""
    exit_code = $null
}

function Write-AuditEvent {
    param(
        [string]$ActionName,
        [string]$ServiceId,
        [string]$Result,
        [string]$Message,
        [string]$Severity = "",
        [int]$ExitCode = -1,
        [string]$MetadataJson = ""
    )

    if (-not $script:auditEnabled) { return }

    $args = @(
        $script:python.Source,
        $script:auditScript,
        "--log",
        "--action", $ActionName,
        "--service-id", $ServiceId,
        "--result", $Result,
        "--message", $Message
    )

    if ($Severity) { $args += "--severity"; $args += $Severity }
    if ($ExitCode -ge 0) { $args += "--exit-code"; $args += $ExitCode }
    if ($MetadataJson) { $args += "--metadata"; $args += $MetadataJson }

    $null = & $args[0] @($args[1..($args.Length-1)])
}

$remotePid = Test-PortOpen $remoteHost ([int]$remotePort) 500
$localPid = Get-PortPids $service.port

switch ($Action) {
    'status' {
        $status = [ordered]@{
            id = $service.id
            name = $service.name
            port = $service.port
            managed = [bool]$service.managed
            local_running = [bool]$localPid
            local_pids = @($localPid)
            remote_running = $remotePid
            cmd = $service.cmd
            note = $service.note
        }
        ($status | ConvertTo-Json -Depth 4)
        Write-AuditEvent -ActionName "status" -ServiceId $service.id -Result "ok" -Message "status check" -MetadataJson (ConvertTo-Json @($remotePid,$localPid) -Compress)
        exit 0
    }
    'selfcheck' {
        $cwdOk = $false
        if ($serviceCwd) { $cwdOk = (Test-Path $serviceCwd) }
        $logPath = Join-Path $PSScriptRoot ('logs\' + $service.id + '.log')
        $status = [ordered]@{
            id = $service.id
            name = $service.name
            managed = [bool]$service.managed
            configured = $true
            cwd = $serviceCwd
            cwd_exists = $cwdOk
            cmd = $service.cmd
            local_running = [bool]$localPid
            remote_running = $remotePid
            notes = $service.note
            log_exists = (Test-Path $logPath)
        }
        if (Test-Path $logPath) {
            $status['log_tail'] = (Get-Content $logPath -Tail 20 | Out-String)
        } else {
            $status['log_tail'] = ""
        }
        Write-AuditEvent -ActionName "selfcheck" -ServiceId $service.id -Result "ok" -Message "selfcheck completed" -MetadataJson (@{ 
            cwd_exists = $cwdOk
            remote_running = [bool]$remotePid
            local_running = [bool]$localPid
        } | ConvertTo-Json -Compress)
        ($status | ConvertTo-Json -Depth 6)
        exit 0
    }
    'start' {
        if ($remotePid) {
            Write-Output ("{\"status\":\"skipped\",\"reason\":\"running_on_remote\",\"service\":\"$($service.id)\"}")
            Write-AuditEvent -ActionName "start" -ServiceId $service.id -Result "skipped" -Message "remote service running; start skipped"
            exit 0
        }
        if ($localPid) {
            Write-Output ("{\"status\":\"already_running_local\",\"service\":\"$($service.id)\",\"pids\":" + (ConvertTo-Json @($localPid)) + "}")
            Write-AuditEvent -ActionName "start" -ServiceId $service.id -Result "already_running_local" -Message "local service already running"
            exit 0
        }
        if (-not $service.managed) {
            Write-Output ("{\"status\":\"manual\",\"reason\":\"$($service.note)\",\"service\":\"$($service.id)\"}")
            Write-AuditEvent -ActionName "start" -ServiceId $service.id -Result "manual" -Message "service not managed"
            exit 2
        }
        if ([string]::IsNullOrWhiteSpace($serviceCwd) -or -not (Test-Path $serviceCwd)) {
            Write-Output "{\"status\":\"failed\",\"reason\":\"working_dir_missing\",\"service\":\"$($service.id)\"}"
            Write-AuditEvent -ActionName "start" -ServiceId $service.id -Result "failed" -Message "missing working dir" -Severity "error" -MetadataJson (@{ cwd = $serviceCwd } | ConvertTo-Json -Compress)
            exit 3
        }
        if ([string]::IsNullOrWhiteSpace($service.cmd)) {
            Write-Output "{\"status\":\"failed\",\"reason\":\"missing_start_command\",\"service\":\"$($service.id)\"}"
            Write-AuditEvent -ActionName "start" -ServiceId $service.id -Result "failed" -Message "missing start command" -Severity "error"
            exit 4
        }

        New-Item -ItemType Directory -Path (Join-Path $PSScriptRoot 'logs') -Force | Out-Null
        $logPath = Join-Path $PSScriptRoot ('logs\' + $service.id + '.log')
        $null = New-Item -ItemType File -Path $logPath -Force
        $command = "cd /d \"$serviceCwd\" && $($service.cmd) >> \"$logPath\" 2>&1"

        $proc = Start-Process -FilePath $env:ComSpec -ArgumentList @('/c',$command) -WindowStyle Minimized -PassThru
        Start-Sleep -Seconds 1
        if (Wait-ServiceUp $service.port 10) {
            $pidsNow = Get-PortPids $service.port
            Write-Output ("{\"status\":\"started\",\"service\":\"$($service.id)\",\"pids\":" + (ConvertTo-Json @($pidsNow)) + ",\"log\":\"$logPath\"}")
            Write-AuditEvent -ActionName "start" -ServiceId $service.id -Result "started" -Message "service start succeeded"
            exit 0
        }

        Write-Output ("{\"status\":\"start_failed\",\"service\":\"$($service.id)\",\"log\":\"$logPath\"}")
        Write-AuditEvent -ActionName "start" -ServiceId $service.id -Result "start_failed" -Message "process did not bind port in window" -Severity "error"
        exit 5
    }
    'stop' {
        if ($remotePid) {
            Write-Output ("{\"status\":\"skipped\",\"reason\":\"running_on_remote\",\"service\":\"$($service.id)\"}")
            Write-AuditEvent -ActionName "stop" -ServiceId $service.id -Result "skipped" -Message "remote service running; stop skipped"
            exit 0
        }
        if (-not $localPid) {
            Write-Output ("{\"status\":\"not_running\",\"service\":\"$($service.id)\"}")
            Write-AuditEvent -ActionName "stop" -ServiceId $service.id -Result "not_running" -Message "local service not running"
            exit 0
        }
        $killed = @()
        foreach ($p in $localPid) {
            try {
                Stop-Process -Id $p -Force -ErrorAction Stop
                $killed += $p
            } catch {}
        }
        Start-Sleep -Milliseconds 600
        $still = Get-PortPids $service.port
        if ($still) {
            Write-Output ("{\"status\":\"stop_failed\",\"service\":\"$($service.id)\",\"pids\":" + (ConvertTo-Json @($still)) + "}")
            Write-AuditEvent -ActionName "stop" -ServiceId $service.id -Result "failed" -Message "process remained after stop" -Severity "error" -MetadataJson (@{ pids = $still } | ConvertTo-Json -Compress)
            exit 6
        }
        Write-Output ("{\"status\":\"stopped\",\"service\":\"$($service.id)\",\"killed\":" + (ConvertTo-Json @($killed)) + "}")
        Write-AuditEvent -ActionName "stop" -ServiceId $service.id -Result "stopped" -Message "service stop succeeded" -MetadataJson (@{ killed = $killed } | ConvertTo-Json -Compress)
        exit 0
    }
}
