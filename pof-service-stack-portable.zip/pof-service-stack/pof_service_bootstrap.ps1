param(
    [string]$ConfigPath = (Join-Path $PSScriptRoot 'service_bundle.config.json')
)

$cfg = Get-Content -LiteralPath $ConfigPath -Raw | ConvertFrom-Json
$remoteHost = if ($env:POF_REMOTE_HOST) { $env:POF_REMOTE_HOST } else { $cfg.bootstrap.remote_host }
$remotePort = if ($env:POF_REMOTE_PORT) { [int]$env:POF_REMOTE_PORT } else { [int]$cfg.bootstrap.remote_port }

function Test-Port {
    param([string]$Host,[int]$Port,[int]$TimeoutMs=600)
    $client = New-Object System.Net.Sockets.TcpClient
    try {
        $ar = $client.BeginConnect($Host,$Port,$null,$null)
        if ($ar.AsyncWaitHandle.WaitOne($TimeoutMs,$true) -and $client.Connected) {
            $client.EndConnect($ar)
            $client.Close()
            return $true
        }
    } catch {}
    return $false
}

$remoteManager = Test-Port $remoteHost $remotePort
if ($remoteManager) {
    Write-Output "[boot] remote manager available at http://$remoteHost`:$remotePort — using remote dashboard, skipping local start."
    if ($env:POF_DISABLE_BROWSER -ne '1') {
        Start-Process "http://$remoteHost`:$remotePort"
    }
    exit 0
}

$localManager = Test-Port '127.0.0.1' $cfg.bootstrap.manager.port
if (-not $localManager) {
    Write-Output "[boot] remote manager not reachable. starting local service manager..."
    $managerPath = if ($cfg.bootstrap.manager.cwd -eq '__SELF__') {
        Join-Path $PSScriptRoot $cfg.bootstrap.manager.script
    } else {
        Join-Path $cfg.bootstrap.manager.cwd $cfg.bootstrap.manager.script
    }
    $managerCwd = if ($cfg.bootstrap.manager.cwd -eq '__SELF__') {
        $PSScriptRoot
    } else {
        $cfg.bootstrap.manager.cwd
    }
    if (-not (Test-Path $managerPath)) {
        Write-Error "Manager missing: $managerPath"
        exit 10
    }
    if (-not (Test-Path $managerCwd)) {
        Write-Error "Manager working dir missing: $managerCwd"
        exit 11
    }

    $cmd = "cd /d `"$managerCwd`" && python $($cfg.bootstrap.manager.script)"
    Start-Process -FilePath $env:ComSpec -ArgumentList @('/c',$cmd) -WindowStyle Minimized | Out-Null
    Start-Sleep -Seconds $cfg.bootstrap.manager.startup_delay_sec
}

if (Test-Port '127.0.0.1' $cfg.bootstrap.manager.port) {
    Write-Output "[boot] manager online: http://127.0.0.1:$($cfg.bootstrap.manager.port)"
    if ($env:POF_DISABLE_BROWSER -ne '1') {
        Start-Process "http://127.0.0.1:$($cfg.bootstrap.manager.port)"
    }
    exit 0
}

Write-Error "[boot] manager did not start on port $($cfg.bootstrap.manager.port)."
exit 12
