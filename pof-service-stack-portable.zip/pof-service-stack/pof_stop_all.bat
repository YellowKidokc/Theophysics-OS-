@echo off
setlocal
for %%I in (nlp_api clipsync fis organize) do (
  echo stopping %%I...
  call "%%~dp0service_%%I.bat" stop
)
