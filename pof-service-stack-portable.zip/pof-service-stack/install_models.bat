@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install_models.ps1" %*
exit /b %ERRORLEVEL%

