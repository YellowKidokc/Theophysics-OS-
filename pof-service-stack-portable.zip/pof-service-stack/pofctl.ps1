param(
    [Parameter(Position = 0, ValueFromRemainingArguments = $true)]
    [string[]]$Arguments
)

$ScriptRoot = $PSScriptRoot
$ConfigPath = Join-Path $ScriptRoot 'service_bundle.config.json'
$AuditPath = Join-Path $ScriptRoot 'pof_audit.py'
$BootstrapBat = Join-Path $ScriptRoot 'pof_service_bootstrap.bat'
$StartAll = Join-Path $ScriptRoot 'pof_start_all.bat'
$StopAll = Join-Path $ScriptRoot 'pof_stop_all.bat'
$CheckAll = Join-Path $ScriptRoot 'pof_check_all.bat'
$SelfcheckAll = Join-Path $ScriptRoot 'pof_selfcheck_all.bat'
$SyncBundle = Join-Path $ScriptRoot 'pof_sync_bundle.bat'
$InstallModels = Join-Path $ScriptRoot 'install_models.bat'

if (-not (Test-Path $ConfigPath)) {
    Write-Error "[pofctl] missing config: $ConfigPath"
    exit 1
}

try {
    $cfg = Get-Content -LiteralPath $ConfigPath -Raw | ConvertFrom-Json
} catch {
    Write-Error "[pofctl] invalid json in $ConfigPath : $($_.Exception.Message)"
    exit 1
}

$commands = @{}
$commands['boot'] = 'boot'
$commands['start'] = 'start'
$commands['stop'] = 'stop'
$commands['status'] = 'status'
$commands['check'] = 'check'
$commands['selfcheck'] = 'selfcheck'
$commands['start-all'] = 'start-all'
$commands['stop-all'] = 'stop-all'
$commands['audit'] = 'audit'
$commands['models'] = 'models'
$commands['sync'] = 'sync'
$commands['bundle'] = 'sync'
$commands['release'] = 'sync'
$commands['doctor'] = 'doctor'
$commands['list'] = 'list'
$commands['runbook'] = 'runbook'
$commands['plan'] = 'runbook'
$commands['help'] = 'help'
$commands['-h'] = 'help'
$commands['--help'] = 'help'

if (-not $Arguments -or $Arguments.Count -eq 0) {
    $cmd = 'help'
    $args = @()
} else {
    $cmd = ($Arguments[0] -replace '^-+','').ToLower()
    $args = @()
    if ($Arguments.Count -gt 1) { $args = $Arguments[1..($Arguments.Count - 1)] }
}

if (-not $commands.ContainsKey($cmd)) {
    $cmd = $args.Count -gt 0 ? $null : $null
}

if ($null -eq $cmd -or $commands[$cmd] -eq $null) {
    $maybeService = $Arguments[0]
    $maybeAction = if ($Arguments.Count -gt 1) { $Arguments[1].ToLower() } else { 'status' }
    $serviceIds = @($cfg.services | ForEach-Object { $_.id })
    if ($serviceIds -contains $maybeService) {
        if ($maybeAction -notin @('start','stop','status','selfcheck')) {
            Write-Error "[pofctl] unknown action '$maybeAction'. Use start|stop|status|selfcheck"
            exit 2
        }
        $serviceBat = Join-Path $ScriptRoot ("service_{0}.bat" -f $maybeService)
        if (-not (Test-Path $serviceBat)) {
            Write-Error "[pofctl] service script missing: $serviceBat"
            exit 3
        }
        & $serviceBat $maybeAction
        exit $LASTEXITCODE
    }
    Write-Error "[pofctl] unknown command '$($Arguments[0])'. Run 'pofctl help'."
    exit 2
}

$cmd = $commands[$cmd]

function Invoke-IfExists {
    param([string]$Path, [string[]]$PassArgs = @())
    if (-not (Test-Path $Path)) {
        Write-Error "[pofctl] missing script: $Path"
        exit 1
    }
    if ($PassArgs -and $PassArgs.Count -gt 0) {
        & $Path @PassArgs
    } else {
        & $Path
    }
    if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
}

function Write-Header($text) {
    Write-Host ""
    Write-Host "==================== $text ====================" -ForegroundColor Cyan
}

function Write-Step([int]$index, [string]$title, [string]$detail) {
    Write-Host ("[{0:00}] {1}" -f $index, $title) -ForegroundColor Yellow
    Write-Host ("     {0}" -f $detail) -ForegroundColor DarkGray
}

function Show-DoctorSummary {
    Write-Host "[pofctl] control root: $ScriptRoot"
    Write-Host ("[pofctl] remote manager: {0}:{1}" -f $cfg.bootstrap.remote_host, $cfg.bootstrap.remote_port)
    Write-Host ("[pofctl] manager port: {0}" -f $cfg.bootstrap.manager.port)
    Write-Host "[pofctl] required scripts:"
    $required = @($BootstrapBat, $StartAll, $StopAll, $CheckAll, $SelfcheckAll, $SyncBundle, $InstallModels, $AuditPath)
    foreach ($r in $required) {
        if (Test-Path $r) {
            Write-Host "  OK  $([System.IO.Path]::GetFileName($r))"
        } else {
            Write-Host "  MISSING $([System.IO.Path]::GetFileName($r))"
        }
    }
    Write-Host '[pofctl] services:'
    foreach ($s in $cfg.services) {
        $marker = if ($s.managed) { 'managed' } else { 'manual' }
        Write-Host ("  - {0} : {1} (:{2}) [{3}]" -f $s.id, $s.name, $s.port, $marker)
    }
    $python = Get-Command python -ErrorAction SilentlyContinue
    Write-Host ("[pofctl] python: {0}" -f ($(if ($python) { $python.Source } else { 'not found' })))
}

switch ($cmd) {
    'boot' {
        Invoke-IfExists $BootstrapBat
    }
    'start' {
        if ($args.Count -eq 0) {
            Invoke-IfExists $StartAll
        } else {
            $svc = $args[0]
            $svcBat = Join-Path $ScriptRoot ("service_{0}.bat" -f $svc)
            Invoke-IfExists $svcBat @('start')
        }
    }
    'stop' {
        if ($args.Count -eq 0) {
            Invoke-IfExists $StopAll
        } else {
            $svc = $args[0]
            $svcBat = Join-Path $ScriptRoot ("service_{0}.bat" -f $svc)
            Invoke-IfExists $svcBat @('stop')
        }
    }
    'status' {
        Invoke-IfExists $CheckAll
    }
    'check' {
        Invoke-IfExists $CheckAll
    }
    'selfcheck' {
        Invoke-IfExists $SelfcheckAll
    }
    'start-all' {
        Invoke-IfExists $StartAll
    }
    'stop-all' {
        Invoke-IfExists $StopAll
    }
    'audit' {
        $limit = 200
        $severity = ''
        $showJson = $true
        for ($i = 0; $i -lt $args.Count; $i++) {
            switch ($args[$i].ToLower()) {
                '--limit' { if ($i + 1 -lt $args.Count) { $limit = [int]$args[$i + 1]; $i++ } }
                '-n' { if ($i + 1 -lt $args.Count) { $limit = [int]$args[$i + 1]; $i++ } }
                '--severity' { if ($i + 1 -lt $args.Count) { $severity = $args[$i + 1]; $i++ } }
                '--plain' { $showJson = $false }
                default {
                    Write-Warning "[pofctl] unrecognized audit arg '$($args[$i])'"
                }
            }
        }

        if (-not (Get-Command python -ErrorAction SilentlyContinue)) {
            Write-Error "[pofctl] python not found in PATH"
            exit 1
        }
        $auditArgs = @("$AuditPath", "--list", "--limit", "$limit", "--json")
        if ($severity) { $auditArgs += "--severity"; $auditArgs += $severity }
        $raw = & python @auditArgs
        if ($showJson) {
            $raw
        } else {
            $rows = $raw | ConvertFrom-Json
            foreach ($r in $rows) {
                '{0} | {1} | {2} | {3} | {4}' -f $r.created_ts, $r.host, $r.action, $r.service_id, $r.result
            }
        }
    }
    'models' {
        if (-not (Test-Path $InstallModels)) {
            Write-Error "[pofctl] install script missing: $InstallModels"
            exit 1
        }
        if ($args.Count -eq 0) {
            & $InstallModels --help
        } else {
            & $InstallModels @args
        }
    }
    'sync' {
        Invoke-IfExists $SyncBundle
    }
    'doctor' {
        Show-DoctorSummary
    }
    'list' {
        Write-Host "[pofctl] services in config:"
        foreach ($s in $cfg.services) {
            Write-Host ('  {0} -> http://localhost:{1} managed={2}' -f $s.id, $s.port, $s.managed)
        }
    }
    'runbook' {
        $runbookMode = $args -contains '--execute' -or $args -contains '-x'

        Write-Header "POF Service Stack Runbook"
        Write-Host "Use `pofctl runbook --execute` to perform the full sequence." -ForegroundColor Gray
        Write-Step 1 "Preflight" "Validate config + required scripts + python environment (`pofctl doctor`)"
        Write-Step 2 "Bootstrap manager" "Remote-first bootstrap (`pofctl boot`) and open dashboard if available."
        Write-Step 3 "Start managed services" "Start all configured managed services (`pofctl start`)."
        Write-Step 4 "Health verification" "Get aggregated status for all services (`pofctl status`)."
        Write-Step 5 "Distribution artifacts" "Generate and sync zip/hash/manifest (`pofctl sync`)."

        if (-not $runbookMode) {
            Write-Host "`nDry run complete. Append --execute to run the ordered sequence." -ForegroundColor Gray
            return
        }

        Write-Host "`n[RUN] Executing ordered sequence..." -ForegroundColor Green
        Write-Header "1) Preflight"
        Show-DoctorSummary

        Write-Header "2) Bootstrap manager"
        Invoke-IfExists $BootstrapBat

        Write-Header "3) Start managed services"
        Invoke-IfExists $StartAll

        Write-Header "4) Health verification"
        Invoke-IfExists $CheckAll

        Write-Header "5) Distribution artifacts"
        Invoke-IfExists $SyncBundle

        Write-Host "`nRunbook complete." -ForegroundColor Green
    }
    default {
        @'
Usage:
  pofctl boot                              # remote-first bootstrap + launch dashboard
  pofctl runbook [--execute]               # ordered operator sequence (boot -> start -> check -> sync)
  pofctl status                           # all services summary
  pofctl selfcheck                        # all services diagnostics
  pofctl start|stop [service-id]          # start all services or one service
  pofctl <service-id> status|start|stop|selfcheck
  pofctl start-all | stop-all
  pofctl audit [--severity error|warning|info] [--limit N] [--plain]
  pofctl models [args...]                 # proxy to install_models.bat
  pofctl sync                              # export bundle + copy to D:\GitHub\Theophysics-OS-
  pofctl release                           # same as sync
  pofctl doctor                          # validate local config and scripts
  pofctl list                            # print configured service ids
  pofctl help
'@ | Write-Host
    }
}
