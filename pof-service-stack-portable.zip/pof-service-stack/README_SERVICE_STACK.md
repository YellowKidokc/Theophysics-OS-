# POF Service Stack (portable control folder)

This folder contains:
- service_bundle.config.json : service definitions + remote fallback host
- pof_service_bootstrap.ps1 / pof_service_bootstrap.bat : one-click launcher (self-check + remote-first)
- pof_service_ctl.ps1 : shared controller for individual start/stop/status/diagnostics
- service_<id>.bat : one command script per service
- pof_start_all.bat / pof_stop_all.bat / pof_check_all.bat / pof_selfcheck_all.bat

Startup behavior:
1) It checks remote dashboard at `http://<remote_host>:9999`
2) If remote is up, it opens that dashboard and skips local boot
3) If remote is down, it starts the local dashboard from this folder and can start local managed services

Usage:
- pof_service_bootstrap.bat              -> startup bootstrap
- service_<id>.bat start                  -> start one service (or skip if remote already serves it)
- service_<id>.bat status                 -> local/remote status JSON
- service_<id>.bat stop                   -> stop local service by PID on that port
- service_<id>.bat selfcheck              -> health + notes + log tail
- pof_start_all.bat                       -> start managed local services
- pof_stop_all.bat                        -> stop managed local services
- pof_check_all.bat                       -> status all services
- pof_selfcheck_all.bat                   -> diagnostics all services

For remote-first control:
- If remote dashboard is running, keep laptop light and use desktop UI there.
- If not, laptop takes over locally.

Portable folder flow:
- Move/copy this entire `pof-service-stack` folder and run `START_SERVICE_MANAGER.bat` from
  `Startup\\` (or run `pof-service-stack\pof_service_bootstrap.bat` directly).
- Configure remote target with `POF_REMOTE_HOST` and `POF_REMOTE_PORT` env vars if needed.
- Set `bootstrap.manager.cwd` to `"__SELF__"` (already done) so the local dashboard starts from bundle path.
- Per-service scripts are:
  - `service_<id>.bat start|status|stop|selfcheck`
  - `pof_start_all.bat`, `pof_stop_all.bat`, `pof_check_all.bat`, `pof_selfcheck_all.bat`
- For cross-machine failover:
  - The laptop will prefer the desktop if remote is healthy.
  - If desktop is unavailable, laptop runs local startup and serves dashboard on `http://localhost:9999`.

## Local audit trail (SQLite, automatic prune)

The stack includes persistent local logging with `pof_audit.py` for durable visibility into service actions.

- DB path: `pof-service-stack/data/events.sqlite`
- Log source:
  - `service_manager.py` for dashboard/API actions (`start`, `stop`, `stack_boot`, status checks)
  - `pof_service_ctl.ps1` for per-service `start|stop|status|selfcheck` events
- API endpoint:
  - `GET /api/audit?limit=200`
  - Optional `severity=error|warning|info`
- CLI:
  - `python pof_audit.py --list --limit 100 --json`
  - `python pof_audit.py --log --action test --service-id nlp_api --result started --message "sample"`

Retention policy (configurable env vars):
- `POF_AUDIT_KEEP_DAYS_OK` (default `30`) for normal info
- `POF_AUDIT_KEEP_DAYS_WARNING` (default `30`) for warnings
- `POF_AUDIT_KEEP_DAYS_ERROR` (default `90`) for errors
- `POF_AUDIT_KEEP_DAYS_IF_LARGE` (default `30`) tighter cut when DB is oversized
- `POF_AUDIT_MAX_DB_MB` (default `25`) maximum SQLite file size before tighter prune

Suggested operational behavior:
- If service churn is heavy, keep warning/error DB cleanup defaults, or increase error retention only if needed.
- Errors are kept longer by design so regressions are traceable after normal cleanup.

## 5-6 Digit Port Segments (future-ready)

Think of this as the stack map you can grow into before adding new services:

- 00000-01099: legacy/system/legacy tools (internal only).
- 01100-01999: control plane + managers (dashboard, health, installer, CLI APIs).
- 02000-02999: NLP and model-serving (current NLP API can stay at 8700 or move here).
- 03000-03999: station/data services (file intelligence, classification, local collectors).
- 04000-04999: synchronization + collaboration (clipsync, peer transport, message bus).
- 05000-05999: database and storage backends (Postgres/vector backends/caches).
- 06000-06999: UI/front-end dev and internal dashboards.
- 07000-07999: media/automation/agent tooling (browser automation, OBS, desktop helpers).
- 08000-08999: integration adapters (Cloudflare, clipboard cloud bridges, external APIs).
- 09000-09999: communication hub / effectors (safe outbound action APIs).
- 10000-19999: optional boundary for externally reachable APIs (only if needed, behind auth).
- 20000-99999: reserved for future expansion and temporary staging.

Current stack mapping (for now):
- Manager dashboard: `9999`
- NLP API (FastAPI): `8700`
- ClipSync: `3456`
- BIL: `8420`
- FIS: `8450`
- Organize: `8500`
- ActivityWatch: `5600`
- Syncthing: `8384`
- BrowserOS: `9200`
- PostgreSQL: `5432`
- Vite: `5173`
- OpenWebUI: `8080`

Practical rule:
- Reserve 5/6-digit blocks before adding new services.
- Keep sensitive services non-exposed unless they are behind auth.
- Prefer localhost binding by default.
- Use environment variables or `.env` files for credentials, never inline in bat/cmd.

If anything is exposed publicly:
- Place it behind a reverse proxy / ZeroTrust control path (Cloudflare Tunnel, proxy + JWT/OIDC).
- Use allowlists for management endpoints.
- Keep only intentional effectors open in the 09000-09999 band and audit those first.

Transfer bundle:
- run `pof_export_bundle.bat` from Startup.
- it creates `pof-service-stack-portable.zip` in the same Startup folder.
- copy that zip to the laptop and unzip, then run `START_SERVICE_MANAGER.bat`.
Model tools:
- install_models.bat <model-id>  -> install one model pack using nearby downloader
- install_models.bat <model-id> -- --destination <path>  -> override destination
- install_models.bat --help      -> shows downloader usage

Recommended workflow:
- Keep MODEL_REGISTRY.json close to your model tooling for source truth.
- For portable installs, use this from inside the stack folder on each machine.
- Configure downloader path if needed via env var `POF_MODEL_DOWNLOAD_SCRIPT`.

Windows service control (optional):
- pof_service_windows_service.bat install [ServiceName]
- pof_service_windows_service.bat start [ServiceName]
- pof_service_windows_service.bat stop [ServiceName]
- pof_service_windows_service.bat restart [ServiceName]
- pof_service_windows_service.bat status [ServiceName]
- pof_service_windows_service.bat uninstall [ServiceName]

Default service name is `POF-ServiceManager`.

If NSSM is installed, the script uses NSSM and enables service logs (`logs\\service_manager_*.log`).

Release artifact output:
- `pofctl.bat sync` now produces and syncs three files:
  - `pof-service-stack-portable.zip`
  - `pof-service-stack-portable.sha256`
  - `pof-service-stack-release.json`
- The release metadata includes `version` from `VERSION` and a UTC build timestamp.
- Default destination remains: `D:\GitHub\Theophysics-OS-`.

Verify a package:
- `Get-FileHash D:\GitHub\Theophysics-OS-\pof-service-stack-portable.zip -Algorithm SHA256`
- compare to `D:\GitHub\Theophysics-OS-\pof-service-stack-portable.sha256`.

## Quick control commands (`pofctl`)

- `pofctl.bat boot`  
  remote-first bootstrap and open dashboard.
- `pofctl.bat start [service-id]`  
  start all managed services, or one service by id.
- `pofctl.bat stop [service-id]`
- `pofctl.bat status`  
  equivalent of `pof_check_all.bat` (all service status).
- `pofctl.bat selfcheck`
- `pofctl.bat start-all` / `pofctl.bat stop-all`
- `pofctl.bat runbook [--execute]`  
  canonical install/recovery sequence view or execute all setup/health steps.
- `pofctl.bat nlp_api start|status|stop|selfcheck`  
  direct per-service command (`service_<id>.bat <action>`).
- `pofctl.bat audit [--severity error|warning|info] [--limit N] [--plain]`
- `pofctl.bat models [--help|<args>]`  
  forwards to `install_models.bat`.
- `pofctl.bat sync`  
  rebuild portable zip and copy to `D:\GitHub\Theophysics-OS-`.
- `pofctl.bat release`  
  same as `sync` (explicit release workflow).
- `pofctl.bat doctor`  
  validates local scripts/config.
- `pofctl.bat list`
