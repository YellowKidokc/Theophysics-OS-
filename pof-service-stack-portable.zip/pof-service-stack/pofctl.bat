@echo off
setlocal

set "POFCTL=%~dp0pofctl.ps1"
if not exist "%POFCTL%" (
  echo [pofctl] missing: %POFCTL%
  exit /b 1
)

powershell -NoProfile -ExecutionPolicy Bypass -File "%POFCTL%" %*
exit /b %ERRORLEVEL%

