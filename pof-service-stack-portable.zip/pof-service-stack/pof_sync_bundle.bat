@echo off
setlocal
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0pof_release.ps1" %*
exit /b %ERRORLEVEL%
