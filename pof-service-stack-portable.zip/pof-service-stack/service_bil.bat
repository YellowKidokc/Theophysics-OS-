@echo off
if "%~1"=="" (
  set "ACTION=status"
) else (
  set "ACTION=%~1"
)
if /I "%ACTION%"=="diag" set "ACTION=selfcheck"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0pof_service_ctl.ps1" -ServiceId bil -Action %ACTION%
