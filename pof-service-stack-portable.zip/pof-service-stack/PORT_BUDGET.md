# Port Budget and Service Expansion

Use this file as the long-term plan for ports and future growth.

## Current strategy

Use `service_bundle.config.json` for actual runtime entries.
Use this budget map when adding new services:

- 00000-01099: legacy / internal system tools
- 01100-01999: control plane, managers, installers, and status endpoints
- 02000-02999: NLP services and model runners
- 03000-03999: station pipelines, file/intelligence workers
- 04000-04999: sync, collaboration, and replication services
- 05000-05999: persistence and cache backends
- 06000-06999: UI dashboards and local development servers
- 07000-07999: automation / media / desktop agent tooling
- 08000-08999: integrations and external bridges
- 09000-09999: communication hub + effectors
- 10000-19999: external-facing APIs (only with explicit auth and allowlist)
- 20000-99999: future feature expansion

## What to set when adding a new service

1. Use a free port inside the correct range.
2. Add the service to `service_bundle.config.json` with:
   - `id`, `name`, `port`, `cwd`, `cmd`, `managed`, `critical`, `note`
3. Copy `service_template.json`, fill values, then generate:
   - `service_<id>.bat` using the same id.
4. Choose `risk` and `public` correctly:
   - `internal`: default (localhost only)
   - `public`: only if behind auth/proxy guard
5. Confirm with:
   - `pof_check_all.bat`
   - `pof_selfcheck_all.bat`
6. If `managed=true`, validate with:
   - `service_<id>.bat start`
   - `service_<id>.bat stop`

## Recommended conventions

- Keep sensitive internals on `localhost` binding only.
- Expose only through a proxy + auth when public access is required.
- Document the reason for any port in `note`.
- Prefer stable ports once set (avoid churn for clients).
