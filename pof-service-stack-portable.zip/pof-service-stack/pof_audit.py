"""
POF Service Stack Audit Logger
Persistent SQLite audit trail for service actions + automatic retention.
"""

import json
import os
import sqlite3
import time
import socket
import platform
import argparse
from pathlib import Path
from typing import Any, Dict, Optional


BASE_DIR = Path(__file__).resolve().parent
DEFAULT_DB_PATH = BASE_DIR / "data" / "events.sqlite"


def _env_int(name: str, default: int) -> int:
    try:
        raw = os.environ.get(name)
        if not raw:
            return default
        value = int(str(raw).strip())
        if value < 1:
            return default
        return value
    except Exception:
        return default


def _env_float(name: str, default: float) -> float:
    try:
        raw = os.environ.get(name)
        if not raw:
            return default
        return float(str(raw).strip())
    except Exception:
        return default


def _severity_from_result(result: str) -> str:
    r = (result or "").strip().lower()
    if r in {"ok", "started", "stopped", "skipped", "already_running_local", "already_running", "not_running", "not_found"}:
        return "info"
    if r in {"warn", "warning", "partial", "already_running_remote"}:
        return "warning"
    return "error"


class AuditDB:
    def __init__(self, db_path: Optional[str] = None):
        path_raw = db_path or os.environ.get("POF_AUDIT_DB") or str(DEFAULT_DB_PATH)
        self.path = Path(path_raw)
        if self.path.is_relative():
            self.path = (BASE_DIR / self.path).resolve()
        self.path.parent.mkdir(parents=True, exist_ok=True)

        self.keep_days_ok = _env_int("POF_AUDIT_KEEP_DAYS_OK", 30)
        self.keep_days_warning = _env_int("POF_AUDIT_KEEP_DAYS_WARNING", 30)
        self.keep_days_error = _env_int("POF_AUDIT_KEEP_DAYS_ERROR", 90)
        self.keep_days_maxsize = _env_int("POF_AUDIT_KEEP_DAYS_IF_LARGE", 30)
        self.max_db_mb = _env_int("POF_AUDIT_MAX_DB_MB", 25)
        self.conn = sqlite3.connect(str(self.path), check_same_thread=False)
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.row_factory = sqlite3.Row
        self._init_db()
        self._prune_if_needed()

    def _init_db(self):
        self.conn.execute(
            """
            CREATE TABLE IF NOT EXISTS service_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                created_at INTEGER NOT NULL,
                host TEXT,
                action TEXT NOT NULL,
                service_id TEXT,
                result TEXT,
                severity TEXT NOT NULL,
                exit_code INTEGER,
                message TEXT,
                metadata_json TEXT,
                created_ts TEXT NOT NULL
            )
            """
        )
        self.conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_service_events_created_at ON service_events(created_at)"
        )
        self.conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_service_events_severity ON service_events(severity)"
        )
        self.conn.commit()

    def _utc_iso(self, now: float) -> str:
        return time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime(now)) + "Z"

    def _db_size_mb(self) -> float:
        try:
            return self.path.stat().st_size / (1024 * 1024)
        except Exception:
            return 0.0

    def _prune_by_severity(self, keep_days: int, severity: str):
        cutoff = int(time.time() - 86400 * keep_days)
        self.conn.execute(
            "DELETE FROM service_events WHERE created_at < ? AND severity = ?",
            (cutoff, severity),
        )

    def _prune_if_needed(self):
        self._prune_by_severity(self.keep_days_ok, "info")
        self._prune_by_severity(self.keep_days_warning, "warning")
        self._prune_by_severity(self.keep_days_error, "error")
        self.conn.commit()

        if self._db_size_mb() <= self.max_db_mb:
            return

        # If DB grows too large, perform a tighter prune for non-issues.
        self._prune_by_severity(self.keep_days_maxsize, "info")
        self._prune_by_severity(self.keep_days_maxsize, "warning")
        self.conn.commit()

        if self._db_size_mb() <= self.max_db_mb:
            return

        # Keep error-like rows longer, remove only the oldest very old info rows.
        self.conn.execute("VACUUM")
        self.conn.commit()

    def log(
        self,
        action: str,
        service_id: str = "",
        result: str = "",
        message: str = "",
        exit_code: Optional[int] = None,
        severity: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        ts = time.time()
        sev = severity or _severity_from_result(result)
        host = os.environ.get("COMPUTERNAME") or socket.gethostname() or platform.node() or "unknown"
        meta = metadata or {}

        row = (
            int(ts),
            host,
            (action or "").strip(),
            (service_id or "").strip() or None,
            (result or "").strip() or None,
            sev,
            exit_code,
            (message or "").strip(),
            json.dumps(meta, ensure_ascii=False) if meta else None,
            self._utc_iso(ts),
        )
        self.conn.execute(
            """
            INSERT INTO service_events
            (created_at, host, action, service_id, result, severity, exit_code, message, metadata_json, created_ts)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            row,
        )
        self.conn.commit()
        self._prune_if_needed()

    def recent(self, limit: int = 200, severity: Optional[str] = None):
        sql = "SELECT * FROM service_events"
        params = []
        if severity:
            sql += " WHERE severity = ?"
            params.append(severity)
        sql += " ORDER BY created_at DESC LIMIT ?"
        params.append(int(limit))
        cur = self.conn.execute(sql, params)
        return [dict(r) for r in cur.fetchall()]


_INSTANCE: Optional[AuditDB] = None


def get_audit_db(path: Optional[str] = None) -> AuditDB:
    global _INSTANCE
    if _INSTANCE is None:
        _INSTANCE = AuditDB(path)
    return _INSTANCE


def cli():
    parser = argparse.ArgumentParser(description="POF stack audit helper")
    parser.add_argument("--db", default=None, help="SQLite DB path")
    parser.add_argument("--log", action="store_true", help="Write a single audit event")
    parser.add_argument("--action", default="", help="Action name")
    parser.add_argument("--service-id", default="", dest="service_id", help="Service identifier")
    parser.add_argument("--result", default="", help="Result status")
    parser.add_argument("--message", default="", help="Event message")
    parser.add_argument("--severity", default=None, help="info|warning|error")
    parser.add_argument("--exit-code", type=int, default=None, dest="exit_code", help="Exit code")
    parser.add_argument("--metadata", default="{}", help="JSON metadata object/string")
    parser.add_argument("--list", action="store_true", help="List recent events")
    parser.add_argument("--limit", type=int, default=200, help="List limit")
    parser.add_argument("--json", action="store_true", help="Output list in JSON")
    args = parser.parse_args()

    db = get_audit_db(args.db)
    if args.log:
        meta = {}
        try:
            if args.metadata:
                loaded = json.loads(args.metadata)
                if isinstance(loaded, dict):
                    meta = loaded
        except Exception:
            meta = {}
        db.log(
            action=args.action,
            service_id=args.service_id,
            result=args.result,
            message=args.message,
            exit_code=args.exit_code,
            severity=args.severity,
            metadata=meta,
        )
        return

    if args.list:
        rows = db.recent(limit=args.limit)
        if args.json:
            print(json.dumps(rows, ensure_ascii=False))
            return
        for row in rows:
            print(f"{row['created_ts']} | {row['host']} | {row['action']} | {row['service_id']} | {row['result']} | {row['severity']} | {row['message']}")
        return


if __name__ == "__main__":
    cli()
