@echo off
setlocal
for %%I in (nlp_api clipsync bil fis organize activitywatch syncthing browseros postgres vite openwebui) do (
  echo ---- %%I ----
  call "%%~dp0service_%%I.bat" selfcheck
)
