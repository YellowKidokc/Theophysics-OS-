@echo off
setlocal
for %%I in (nlp_api clipsync fis organize) do (
  echo starting %%I...
  call "%%~dp0service_%%I.bat" start
)
