@echo off
setlocal EnableExtensions EnableDelayedExpansion

set "SERVICE_NAME=%~2"
if not defined SERVICE_NAME set "SERVICE_NAME=POF-ServiceManager"
set "SERVICE_DESC=POF Service Stack Manager"
set "SCRIPT_DIR=%~dp0"
set "PYTHON_EXE="
set "NSSM_EXE="
set "ACTION=%~1"

if /I "%ACTION%"=="" (
    goto usage
)

for /f "delims=" %%I in ('where python 2^>nul') do (
    if not defined PYTHON_EXE set "PYTHON_EXE=%%I"
)
if not defined PYTHON_EXE (
    echo [ERROR] Python not found in PATH.
    exit /b 2
)

if /I "%ACTION%"=="install" (
    call :install
    exit /b %ERRORLEVEL%
)
if /I "%ACTION%"=="uninstall" (
    call :uninstall
    exit /b %ERRORLEVEL%
)
if /I "%ACTION%"=="start" (
    call :start
    exit /b %ERRORLEVEL%
)
if /I "%ACTION%"=="stop" (
    call :stop
    exit /b %ERRORLEVEL%
)
if /I "%ACTION%"=="restart" (
    call :stop
    if errorlevel 1 exit /b %ERRORLEVEL%
    call :start
    exit /b %ERRORLEVEL%
)
if /I "%ACTION%"=="status" (
    call :status
    exit /b %ERRORLEVEL%
)

:usage
echo.
echo POF Service Stack Windows Service helper
echo.
echo Usage:
echo   pof_service_windows_service.bat install [ServiceName]
echo   pof_service_windows_service.bat uninstall [ServiceName]
echo   pof_service_windows_service.bat start [ServiceName]
echo   pof_service_windows_service.bat stop [ServiceName]
echo   pof_service_windows_service.bat restart [ServiceName]
echo   pof_service_windows_service.bat status [ServiceName]
echo.
echo Defaults:
echo   ServiceName = POF-ServiceManager
exit /b 1

:detect_nssm
for /f "delims=" %%I in ('where nssm 2^>nul') do (
    if not defined NSSM_EXE set "NSSM_EXE=%%I"
)
if not defined NSSM_EXE if exist "%SCRIPT_DIR%nssm.exe" set "NSSM_EXE=%SCRIPT_DIR%nssm.exe"
if not defined NSSM_EXE exit /b 1
exit /b 0

:install
if exist "%SCRIPT_DIR%logs" (
    echo.
) else (
    mkdir "%SCRIPT_DIR%logs" >nul 2>&1
)

call :detect_nssm >nul 2>&1
if not errorlevel 1 goto do_nssm_install

echo [warn] nssm not found in PATH; using native sc.exe fallback.
goto do_sc_install

:do_nssm_install
echo [install] installing with nssm: %SERVICE_NAME%
"%NSSM_EXE%" stop "%SERVICE_NAME%" >nul 2>&1
"%NSSM_EXE%" remove "%SERVICE_NAME%" confirm >nul 2>&1
"%NSSM_EXE%" install "%SERVICE_NAME%" "%PYTHON_EXE%" "%SCRIPT_DIR%service_manager.py"
if errorlevel 1 (
    echo [ERROR] nssm install failed.
    exit /b 3
)
"%NSSM_EXE%" set "%SERVICE_NAME%" AppDirectory "%SCRIPT_DIR%"
"%NSSM_EXE%" set "%SERVICE_NAME%" DisplayName "%SERVICE_DESC%"
"%NSSM_EXE%" set "%SERVICE_NAME%" Description "%SERVICE_DESC%"
"%NSSM_EXE%" set "%SERVICE_NAME%" Start SERVICE_AUTO_START
"%NSSM_EXE%" set "%SERVICE_NAME%" AppStdout "%SCRIPT_DIR%logs\service_manager_stdout.log"
"%NSSM_EXE%" set "%SERVICE_NAME%" AppStderr "%SCRIPT_DIR%logs\service_manager_stderr.log"
"%NSSM_EXE%" set "%SERVICE_NAME%" AppStdioRetention 300
"%NSSM_EXE%" set "%SERVICE_NAME%" AppRotateFiles 1
"%NSSM_EXE%" set "%SERVICE_NAME%" AppRotateOnline 0
"%NSSM_EXE%" set "%SERVICE_NAME%" AppRestartDelay 5000
"%NSSM_EXE%" start "%SERVICE_NAME%"
if errorlevel 1 (
    echo [ERROR] failed to start service with nssm.
    exit /b 4
)
echo [ok] installed and started "%SERVICE_NAME%".
exit /b 0

:do_sc_install
echo [install] installing with sc.exe fallback: %SERVICE_NAME%
sc create "%SERVICE_NAME%" ^
    binPath= "\"%SystemRoot%\\System32\\cmd.exe\" /c \"cd /d \"%SCRIPT_DIR%\" && \"%PYTHON_EXE%\" service_manager.py\"" ^
    DisplayName= "%SERVICE_DESC%" start= delayed-auto >nul
if errorlevel 1 (
    echo [ERROR] sc.exe install failed.
    exit /b 3
)
sc config "%SERVICE_NAME%" obj= LocalSystem >nul
sc failure "%SERVICE_NAME%" reset= 86400 actions= restart/60000/restart/120000// >nul
sc failureflag "%SERVICE_NAME%" 1 >nul
sc start "%SERVICE_NAME%" >nul
if errorlevel 1 (
    echo [ERROR] failed to start service with sc.exe.
    exit /b 4
)
echo [ok] installed and started "%SERVICE_NAME%".
exit /b 0

:uninstall
call :detect_nssm >nul 2>&1
if not errorlevel 1 (
    echo [remove] removing with nssm: %SERVICE_NAME%
    "%NSSM_EXE%" stop "%SERVICE_NAME%" >nul 2>&1
    "%NSSM_EXE%" remove "%SERVICE_NAME%" confirm >nul 2>&1
    echo [ok] removed "%SERVICE_NAME%".
    exit /b 0
)
echo [remove] removing with sc.exe: %SERVICE_NAME%
sc stop "%SERVICE_NAME%" >nul 2>&1
sc delete "%SERVICE_NAME%" >nul
if errorlevel 1 (
    echo [warn] service may not exist.
    exit /b 1
)
echo [ok] removed "%SERVICE_NAME%".
exit /b 0

:start
sc start "%SERVICE_NAME%" >nul
if errorlevel 1 (
    echo [ERROR] could not start "%SERVICE_NAME%".
    exit /b 1
)
echo [ok] start requested for "%SERVICE_NAME%".
exit /b 0

:stop
sc stop "%SERVICE_NAME%" >nul
if errorlevel 1 (
    echo [ERROR] could not stop "%SERVICE_NAME%".
    exit /b 1
)
echo [ok] stop requested for "%SERVICE_NAME%".
exit /b 0

:status
sc query "%SERVICE_NAME%" | findstr /I "SERVICE_NAME STATE"
exit /b 0
